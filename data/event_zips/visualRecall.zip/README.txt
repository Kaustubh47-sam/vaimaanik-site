Visual Recall Participation Certificates
=========================================
Certificates generated: 17
Format: Individual PDF, A4 landscape
Fields populated: participant name, USN, college, event name
Event: Visual Recall

Source note: The uploaded Excel workbooks are Visual Recall feedback-response sheets, not dedicated registration exports. The participant list was deduplicated using name + USN. This ZIP therefore covers the unique people present in those feedback sheets and may not represent every person registered for the event.
